[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-24ddc0f5d75046c5622901739e7c5dd533143b0c8e959d652212380cedb1ea36.svg)](https://classroom.github.com/a/sYysBPd6)


Installations (external)

Some extra software outside of the requirements.txt file has to be installed:


https://github.com/JazzCore/python-pdfkit/wiki/Installing-wkhtmltopdf

In linux: `sudo apt install -y wkhtmltopdf`

On Mac, consider: `brew install wkhtmltopdf`


DRF Spectacular

Run the following command:
   
```
python manage.py spectacular --file schema.yml
```  
