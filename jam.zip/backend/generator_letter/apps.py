from django.apps import AppConfig


class GeneratorLetterConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "generator_letter"
