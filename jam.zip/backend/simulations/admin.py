from django.contrib import admin
from .models import Simulation

# Register your models here.
admin.site.register(Simulation)
