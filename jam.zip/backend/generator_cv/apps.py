from django.apps import AppConfig


class GeneratorCvConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "generator_cv"
